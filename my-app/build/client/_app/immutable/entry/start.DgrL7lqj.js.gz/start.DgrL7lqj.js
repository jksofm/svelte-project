import{a as t}from"../chunks/entry.B4jh6SZj.js";export{t as start};
